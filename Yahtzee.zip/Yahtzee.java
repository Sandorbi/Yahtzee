
/*
 * File: Yahtzee.java
 * ------------------
 * This program will eventually play the Yahtzee game.
 */

import java.util.ArrayList;
import java.util.Arrays;

import acm.io.*;
import acm.program.*;
import acm.util.*;

public class Yahtzee extends GraphicsProgram implements YahtzeeConstants {

	public static void main(String[] args) {
		new Yahtzee().start(args);
	}

	public void run() {
		IODialog dialog = getDialog();
		nPlayers = dialog.readInt("Enter number of players");
		playerNames = new String[nPlayers];
		for (int i = 1; i <= nPlayers; i++) {
			playerNames[i - 1] = dialog.readLine("Enter name for player " + i);
		}
		scoresArr = new int[18][nPlayers];
		categoryMat = new int[15][nPlayers];
		display = new YahtzeeDisplay(getGCanvas(), playerNames);
		playGame();
	}

	// This Method stars playing the game.
	private void playGame() {
		total = 0;
		for (int i = 0; i < 13; i++) {
			for (playerNumber = 1; playerNumber <= nPlayers; playerNumber++) {
				giveTurn();
			}
			playerNumber = 1;
		}
		calculateTotals();
		determineWinner();
	}
	
	
	// After the game is finished this method determines the winner and prints appropriate message with the winners name and score.
	private void determineWinner() {
		int winnerIndex = 0;
		winnerIndex = getWinnerIndex();
		alert(winnerIndex);
	}
	
	// after the game is finished this method calculate total scores of each player.
	private void calculateTotals() {
		for (playerNumber = 1; playerNumber <= nPlayers; playerNumber++) {
			upperTotal = getUpperTotal();
			lowerTotal = getLowerTotal();
			if (upperTotal >= 63) {
				display.updateScorecard(UPPER_BONUS, playerNumber, 35);
				upperTotal += 35;
			} else {
				display.updateScorecard(UPPER_BONUS, playerNumber, 0);
			}
			results();
		}
	}

	// This method updates final results on the board and in the scoresArr.
	private void results() {
		total = upperTotal + lowerTotal;
		scoresArr[TOTAL - 1][playerNumber - 1] = total;
		display.updateScorecard(TOTAL, playerNumber, total);
	}

	// This method returns an index of the winner.
	private int getWinnerIndex() {
		int winnerIndex = 1;
		int highestScore = scoresArr[TOTAL - 1][winnerIndex - 1];
		;
		for (int i = 2; i <= nPlayers; i++) {
			if (scoresArr[TOTAL - 1][i - 1] > highestScore) {
				highestScore = scoresArr[TOTAL - 1][i - 1];
				winnerIndex = i;
			}
		}
		return winnerIndex;
	}

	// This method prints a message, alerting which player has one, with how much score.
	private void alert(int winnerIndex) {
		display.printMessage("Congratulations, " + playerNames[winnerIndex - 1]
				+ " you're the winner with a total score of " + scoresArr[TOTAL - 1][winnerIndex - 1]);
	}

	// This method gives turn to a player.
	private void giveTurn() {
		initialize();
		otherTries();
		chooseCategory();
	}

	// This method initializes the game. Tells the player to roll the dice and displays dice.
	private void initialize() {
		String name = playerNames[playerNumber - 1];
		display.printMessage(name + "'s turn! Click \"Roll Dice\" button to roll the dice");
		for (int i = 0; i < diceArr.length; i++) {
			diceArr[i] = rgen.nextInt(1, 6);
		}
		display.waitForPlayerToClickRoll(playerNumber);
		display.displayDice(diceArr);
	}

	
	// This method gives players another change to reroll the dice.
	private void otherTries() {
		for (int j = 0; j < N_TRIES; j++) {
			display.printMessage("Select the dice you wish to re-roll and click \"Roll again\"");
			display.waitForPlayerToSelectDice();
			for (int k = 0; k < N_DICE - 1; k++) {
				if (display.isDieSelected(k)) {
					diceArr[k] = rgen.nextInt(1, 6);
				}
			}
			display.displayDice(diceArr);
		}
		display.displayDice(diceArr);
	}

	// This method lets player choose category - each category only once.
	private void chooseCategory() {
		display.printMessage("Select a category for this roll");
		int category = display.waitForPlayerToSelectCategory();
		updateCategoryArr(category);
		while (isChosen(category)) {
			display.printMessage("This category is already chosen, please choose a new one");
			category = display.waitForPlayerToSelectCategory();
			updateCategoryArr(category);
		}
		checkChosenCategory(category);
	}

	// Updates categoryMat after the player has chosen the category.
	private void updateCategoryArr(int category) {
		categoryMat[category - 1][playerNumber - 1] += 1;
	}

	// checks whether the chosen category have already been chosen.
	private boolean isChosen(int category) {
		if (categoryMat[category - 1][playerNumber - 1] >= 2) {
			return true;
		}
		return false;
	}

	// This method checks whether rolled combination satisfies the chosen category and updates the score card accordingly.
	private void checkChosenCategory(int category) {
		if (checkCategory(diceArr, category)) {
			categoryScore = getScore(category);
			display.updateScorecard(category, playerNumber, categoryScore);
			categoryScore = 0;
		} else {
			categoryScore = 0;
			display.updateScorecard(category, playerNumber, categoryScore);
		}
	}

	// returns the score from the chosen category.
	private int getScore(int category) {
		if (1 <= category && category <= 6) {
			int upperScore = getUpperScores(category);
			return upperScore;
		} else {
			int lowerScore = getLowerScores(category);
			return lowerScore;
		}
	}

	// returns the score from the upper category list.
	private int getUpperScores(int category) {
		int score = 0;
		for (int i = 0; i < N_DICE; i++) {
			if (category == ONES && diceArr[i] == 1) {
				score++;
			} else if (category == TWOS && diceArr[i] == 2) {
				score += 2;
			} else if (category == THREES && diceArr[i] == 3) {
				score += 3;
			} else if (category == FOURS && diceArr[i] == 4) {
				score += 4;
			} else if (category == FIVES && diceArr[i] == 5) {
				score += 5;
			} else if (category == SIXES && diceArr[i] == 6) {
				score += 6;
			}
		}
		scoresArr[category - 1][playerNumber - 1] = score;
		updateUpperScores(category);
		return scoresArr[category - 1][playerNumber - 1];
	}

	// Updates upper score each time a new upper category is chosen.
	private void updateUpperScores(int category) {
		display.updateScorecard(UPPER_SCORE, playerNumber, getUpperTotal());
	}

	// returns the total score a player has accumulated from the upper categories.
	private int getUpperTotal() {
		int uScore = 0;
		for (int i = 1; i <= 6; i++) {
			uScore += scoresArr[i - 1][playerNumber - 1];
		}
		return uScore;
	}

	// returns the score from the lower categories.
	private int getLowerScores(int category) {
		int score = 0;
		if (category == THREE_OF_A_KIND || category == FOUR_OF_A_KIND) {
			for (int i = 0; i < N_DICE; i++) {
				score += diceArr[i];
			}
		} else if (category == FULL_HOUSE) {
			score += 25;
		} else if (category == SMALL_STRAIGHT) {
			score += 30;
		} else if (category == LARGE_STRAIGHT) {
			score += 40;
		} else if (category == YAHTZEE) {
			score += 50;
		} else if (category == CHANCE) {
			for (int i = 0; i < N_DICE; i++) {
				score += diceArr[i];
			}
		}
		scoresArr[category - 1][playerNumber - 1] = score;
		updateLowerScores(category);
		return scoresArr[category - 1][playerNumber - 1];
	}

	// Updates lower scores each time a new lower cateogry is chosen.
	private void updateLowerScores(int category) {
		lowerTotal = getLowerTotal();
		display.updateScorecard(LOWER_SCORE, playerNumber, getLowerTotal());
	}

	
	// returns the total score a player has accumulated from the lower categories.
	private int getLowerTotal() {
		int lScore = 0;
		for (int i = 9; i <= 15; i++) {
			lScore += scoresArr[i - 1][playerNumber - 1];
		}
		return lScore;
	}

	// This method checks whether the given dice values satisfy the chosen category.
	private boolean checkCategory(int[] diceArr, int category) {
		if (1 <= category && category <= 6) {
			for (int i = 0; i < N_DICE; i++) {
				if (numberExists(category)) {
					return true;
				}
			}
			return false;
		}
		int[] freqArr = getFrequency();
		if (category == THREE_OF_A_KIND && !checkKinds(category, freqArr)) {
			return false;
		}
		if (category == FOUR_OF_A_KIND && !checkKinds(category, freqArr)) {
			return false;
		}
		if (category == FULL_HOUSE && !checkHouse(freqArr)) {
			return false;
		}
		if (category == SMALL_STRAIGHT && !checkStraight(category)) {
			return false;
		}
		if (category == LARGE_STRAIGHT && !checkStraight(category)) {
			return false;
		}
		if (category == YAHTZEE && !checkYahtzee(freqArr)) {
			return false;
		}
		return true;

	}

	// Creates the frequency matrix of dice and determines how many times each dice has come up.
	private int[] getFrequency() {
		int[] freqArr = new int[6];
		for (int i = 0; i < N_DICE; i++) {
			freqArr[diceArr[i] - 1] += 1;
		}
		return freqArr;
	}

	// Checks whether given combination is three of a kind or four of a kind.
	private boolean checkKinds(int category, int[] freqArr) {
		for (int i = 0; i < N_DICE; i++) {
			if (category == THREE_OF_A_KIND && freqArr[i] >= 3) {
				return true;
			}
			if (category == FOUR_OF_A_KIND && freqArr[i] >= 4) {
				return true;
			}
		}
		return false;
	}

	
	//Checks whether given combination is a full house.
	private boolean checkHouse(int[] freqArr) {
		if (checkKinds(THREE_OF_A_KIND, freqArr) && checkPairs(freqArr)) {
			return true;
		}
		return false;
	}

	//Checks whether given combination has pairs in it.
	private boolean checkPairs(int[] freqArr) {
		for (int i = 0; i < N_DICE; i++) {
			if (freqArr[i] == 2) {
				return true;
			}
		}
		return false;
	}

	// Checks whether given combination is a small or a large straight.
	private boolean checkStraight(int category) {
		Arrays.sort(diceArr);
		int counter = 1;
		for (int i = 0; i < N_DICE - 1; i++) {
			if ((diceArr[i + 1] - diceArr[i]) == 1) {
				counter++;
			} else {
				counter = 1;
			}
		}
		if (counter >= 3 && category == SMALL_STRAIGHT) {
			return true;
		}
		if (counter >= 4 && category == LARGE_STRAIGHT) {
			return true;
		}
		return false;
	}

	// Checks whether given combination is Yahtzee.
	private boolean checkYahtzee(int[] freqArr) {
		for (int i = 0; i < N_DICE; i++) {
			if (freqArr[i] == 5) {
				return true;
			}
		}
		return false;
	}

	// Checks whether the given number exists in the combinatin.
	private boolean numberExists(int category) {
		for (int i = 0; i < N_DICE; i++) {
			if (diceArr[i] == category) {
				return true;
			}
		}
		return false;
	}

	/* Private instance variables */
	private int nPlayers;
	private String[] playerNames;
	private YahtzeeDisplay display;
	private RandomGenerator rgen = new RandomGenerator();
	private int[] diceArr = new int[N_DICE];
	private int[][] categoryMat;
	private int categoryScore;
	private int[][] scoresArr;
	private int upperTotal = 0;
	private int lowerTotal = 0;
	private int playerNumber;
	private int total = 0;
	private static final int N_TRIES = 2;
}
